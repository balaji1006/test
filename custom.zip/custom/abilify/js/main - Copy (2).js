(function ($) {
  //alert("Yes its loding");
  
	$('#printcard').on("click", function(e){
		var cardurl = $('#printcard').data('cardurl');
		printJS({printable:cardurl, type:'pdf', showModal:true})
	});
	
	$(window).on("load",function(){
		$("#content-1").mCustomScrollbar({
			theme:"minimal"
		});
	});
  
  	$(".sticky__section").removeClass("max__height");
	$(".Seemore__icon").removeClass("minimize__icon");
    $(".Seemore__icon").click(function(){
        $(".Seemore__icon").toggleClass("minimize__icon");
        $(".sticky__section").toggleClass("max__height");
    });
	
	var checkScroll = function() {
		if ($('.safetyinformation__sec')[0]) {
			var el = $('.safetyinformation__sec');
			var top_of_object = el.offset().top;
			var bottom_of_object = el.offset().top + el.outerHeight();
			var top_of_window = $(window).scrollTop();
			var bottom_of_window = $(window).scrollTop() + $(window).height();

			if (top_of_window <= bottom_of_object && bottom_of_window >= top_of_object) {
			   $('.sticky__section').hide();
			} else {
			 $('.sticky__section').show();
			}
		}
	}

  $(window).on('scroll', function() {checkScroll()});
  

	$('#download-form').on('submit', function (e) {
		if(!$('input[type=checkbox]:checked').length) {
			$("label").addClass("error_msg_down");
			return false;
		}
	   return true; 
	}); 	
	
	$('#signup-form').on('submit', function (e) {
		if (! $('#edit-agree')[0].checked){
			$("#frmagree label").addClass("error_msg_down");
			$("#enrollment h3").addClass("error_msg");
			return false;
		}
	   return true; 
	}); 
	
	
	    $('[data-popup-open]').on('click', function(e)  {
        var targeted_popup_class = jQuery(this).attr('data-popup-open');
        $('[data-popup="' + targeted_popup_class + '"]').fadeIn(350);
		$("video")[0].play();
        e.preventDefault();
    });
 
    //----- CLOSE
    $('[data-popup-close]').on('click', function(e)  {
        var targeted_popup_class = jQuery(this).attr('data-popup-close');
        $('[data-popup="' + targeted_popup_class + '"]').fadeOut(350);
		if ($("video")[0].paused){
			$("video").css('display','block');
			$(".btn").css('display','none');
			$("video")[0].play();
		}
		else{
			$("video")[0].pause();
		}
        e.preventDefault();
    });
    
	var w = $(window).width();
	if (w <= 767) {
	$('.payretail__top').click(function() {
		if ($('.retail-sec').hasClass("active")) {
		  $('.paypls__icon').addClass('min__icon');
		  $('.retail-sec').removeClass('active').slideDown(800);
		} else {
		  $('.paypls__icon').removeClass('min__icon');
		  $('.retail-sec').addClass('active').slideUp(800);
		}
	  });		
	}
	if (w <= 767) {	
		$('.payretail__last').click(function() {
			if ($('.homedelivery').hasClass("active")) {
				$('.paypls__icon1').addClass('min__icon');
				$('.homedelivery').removeClass('active').slideDown(800);
			} else {
				$('.paypls__icon1').removeClass('min__icon');
				$('.homedelivery').addClass('active').slideUp(800);
			}
		}); 
	}
  $(window).trigger('resize');
  
  	$(window).on('resize', function() {

    var w = $(window).width();

    if (w <= 991) {

        $('.menu-mobile').removeClass('active');
        $('.Menu').hide();
        $('.menu-mobile').click(function(e) {
            $('.Menu').slideToggle();
            $(this).toggleClass('active');
            e.stopImmediatePropagation();
        });

    } else {
        $('.Menu').show();
        $('.menu-mobile').removeClass('active');
    }
    if (w <= 767) {
        $('.menu-arrow').click(function(e) {
            if ($(this).next().is(':visible')) {
                $(this).next().slideUp(500).end().removeClass('active');
            } else {
                $('.subMenu__list').slideUp();
                $('.menu-arrow').removeClass('active');
                $(this).next().slideDown(500).end().addClass('active');

            }
            e.stopImmediatePropagation();
        });
        //home tab securityPolicy
    } else {
        $('.Dropdown__list').removeAttr('style');
    }

});
    
 })(jQuery);
	



//Accordian JS

(function(e,t){e.fn.collapsible=function(t,n){var r={accordionUpSpeed:400,accordionDownSpeed:400,collapseSpeed:400,contentOpen:0,arrowRclass:"plus__icon",arrowDclass:"minm__icon",animate:true};if(typeof t==="object"){var i=e.extend(r,t)}else{var i=e.extend(r,n)}return this.each(function(){if(i.animate===false){i.accordionUpSpeed=0;i.accordionDownSpeed=0;i.collapseSpeed=0}var n=e(this).children(":even");var r=e(this).children(":odd");var s="accordion-active";switch(t){case"accordion-open":case"accordion":if(t==="accordion-open"){e(n[i.contentOpen]).children(":first-child").toggleClass(i.arrowRclass+" "+i.arrowDclass);e(r[i.contentOpen]).show().addClass(s)}e(n).click(function(){if(e(this).next().attr("class")===s){e(this).next().slideUp(i.accordionUpSpeed).removeClass(s);e(this).children(":first-child").toggleClass(i.arrowRclass+" "+i.arrowDclass)}else{e(n).children().removeClass(i.arrowDclass).addClass(i.arrowRclass);e(r).slideUp(i.accordionUpSpeed).removeClass(s);e(this).next().slideDown(i.accordionDownSpeed).addClass(s);e(this).children(":first-child").toggleClass(i.arrowRclass+" "+i.arrowDclass)}});break;case"default-open":default:if(t==="default-open"){e(n[i.contentOpen]).children(":first-child").toggleClass(i.arrowRclass+" "+i.arrowDclass);e(r[i.contentOpen]).show()}e(n).click(function(){e(this).children(":first-child").toggleClass(i.arrowRclass+" "+i.arrowDclass);e(this).next().slideToggle(i.collapseSpeed)});break}})}})(jQuery);

(function ($) {
  

$('.accordion_head').addClass('active');
	$('.accordion_head').click(function() {
		if ($(this).hasClass("active")) {
			$(this).removeClass('active');
			
		} else {
			$(this).addClass('active');
			
		}
	});
	
	$('#sixth').collapsible();


})(jQuery);