<?php
/**
 * @file
 * Add custom theme settings to the Abilify theme.
 */
use Drupal\Component\Utility\Html;
use Drupal\Core\Form\FormStateInterface;
use Drupal\system\Form\ThemeSettingsForm;
use Drupal\file\Entity\File;
use Drupal\Core\Url;

/**
 * Implements hook_form_FORM_ID_alter().
 * @param $form
 * @param \Drupal\Core\Form\FormStateInterface $form_state
 */
function abilify_form_system_theme_settings_alter(&$form, FormStateInterface $form_state) {
  $form['settings']['site']['mobile_logo'] = array(
        '#type' => 'managed_file',
        '#title' => t('Upload Mobile logo'),
        '#default_value' => theme_get_setting('mobile_logo', 'abilify'),
        '#upload_location' => 'public://image'
    );
    $theme_file = drupal_get_path('theme', 'abilify') . '/theme-settings.php';
    $build_info = $form_state->getBuildInfo();
    if (!in_array($theme_file, $build_info['files'])) {
        $build_info['files'][] = $theme_file;
    }
    $form_state->setBuildInfo($build_info);

    // Custom submit to save the file permenant.
    $form['#submit'][] = 'abilify_settings_form_submit';
}

function abilify_settings_form_submit(&$form, FormStateInterface $form_state) {
    $account = \Drupal::currentUser();
    $values = $form_state->getValues();

    if (isset($values['mobile_logo']) && !empty($values['mobile_logo'])) {
      // Load the file via file.fid.
      $file = file_load($values['mobile_logo'][0]);
      // Change status to permanent.
      $file->setPermanent();
      $file->save();
      $file_usage = \Drupal::service('file.usage');
      $file_usage->add($file, 'user', 'user', $account->id());
    }
}