<?php

namespace Drupal\savingscard\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

/**
 * Class DownloadForm.
 *
 * @package Drupal\savingscard\Form
 */
class DownloadForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'download_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form['download_info'] = [
      '#type' => 'checkbox',
      '#title' => ('I agree that I have a prescription for ABILIFY (aripiprazole) and commercial insurance. <a href="javascript:;" title="Conditions apply">Conditions apply</a>.'),
      '#attributes' => ['class' => ['download_info']],
      '#required' => FALSE,
      '#prefix' => '<div class="popup__cehckbox"><div class="round">',
      '#suffix' => '</div></div>',
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => 'Download Now',
      '#attributes' => ['class' => ['btn payretail__btn']],
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    global $base_root, $base_url;
    $mem_num = '568609055';
    $grpid = 'ABY56';
    $ceid = '9871';
    $dest_url = '/savings-card-program?&mem_num=' . $mem_num . '&grpid=' . $grpid . '&CEID=' . $ceid;
    $url = Url::fromUri('internal:' . $dest_url);
    $form_state->setRedirectUrl($url);
  }

}
