<?php

namespace Drupal\savingscard\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

use Drupal\Core\Database\Database;
use Drupal\Core\Url;

/**
 * Class SignupForm.
 *
 * @package Drupal\savingscard\Form
 */
class SignupForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'signup_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    global $base_root, $base_url;
    $mem_num = \Drupal::request()->query->get('mem_num');
    $grpid = \Drupal::request()->query->get('grpid');
    $ceid = \Drupal::request()->query->get('CEID');

    $conn = Database::getConnection();
    $record = [];
    if (isset($_GET['num'])) {
      $query = $conn->select('savingscard', 's')
        ->condition('id', $_GET['num'])
        ->fields('s');
      $record = $query->execute()->fetchAssoc();
    }

    $form['sdivleft'] = [
      '#markup' => $this->t('<div class="col-sm-6">'),
    ];

    $form['firstname'] = [
      '#type' => 'textfield',
      '#title' => $this->t('First Name'),
      '#required' => TRUE,
      '#default_value' => (isset($record['firstname']) && $_GET['num']) ? $record['firstname'] : '',
      '#attributes' => ['class' => ['form-control']],
      '#prefix' => '<div class="form-group">',
      '#suffix' => '</div>',
    ];

    $form['lastname'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Last Name'),
      '#required' => TRUE,
      '#default_value' => (isset($record['lastname']) && $_GET['num']) ? $record['lastname'] : '',
      '#attributes' => ['class' => ['form-control']],
      '#prefix' => '<div class="form-group">',
      '#suffix' => '</div>',
    ];

    $form['email'] = [
      '#type' => 'email',
      '#title' => $this->t('E-mail'),
      '#required' => TRUE,
      '#default_value' => (isset($record['email']) && $_GET['num']) ? $record['email'] : '',
      '#attributes' => ['class' => ['form-control']],
      '#prefix' => '<div class="form-group">',
      '#suffix' => '</div>',
    ];
    $form['fieldreq'] = [
      '#markup' => $this->t('<span class="Required__field"><span>*</span>Name and e-mail are required.</span>'),
    ];

    $form['additional_info'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Yes, I would like to receive additional information by mail about ABILIFY and related programs.'),
      '#attributes' => ['class' => ['additional-info']],
      '#prefix' => '<div class="popup__cehckbox"><div class="round">',
      '#suffix' => '</div></div>',
    ];

    $form['edivleft'] = [
      '#markup' => $this->t('</div><div class="col-sm-12"><div class="Others__form"> <span>All fields are required unless otherwise noted.</span> </div>'),
    ];

    $form['saddinfo'] = [
      '#markup' => $this->t('<div class="address-info">'),
    ];

    $form['saddress'] = [
      '#markup' => $this->t('<div class="Others__formsec">'),
    ];

    $form['address1'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Address1'),
      '#required' => FALSE,
      '#default_value' => (isset($record['address1']) && $_GET['num']) ? $record['address1'] : '',
      '#attributes' => ['class' => ['address1-info form-control']],
      '#prefix' => '<div class="form-group">',
      '#suffix' => '</div>',
    ];

    $form['address2'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Address2'),
      '#required' => FALSE,
      '#default_value' => (isset($record['address2']) && $_GET['num']) ? $record['address2'] : '',
      '#attributes' => ['class' => ['form-control']],
      '#prefix' => '<div class="form-group">',
      '#suffix' => '</div>',
    ];

    $form['eaddress'] = [
      '#markup' => $this->t('</div>'),
    ];

    $form['scity'] = [
      '#markup' => $this->t('<div class="Others__formsecother">'),
    ];

    $form['zip'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Zip'),
      '#default_value' => (isset($record['zip']) && $_GET['num']) ? $record['zip'] : '',
      '#attributes' => ['class' => ['form-control']],
      '#prefix' => '<div class="form-group">',
      '#suffix' => '</div>',
    ];

    $form['city'] = [
      '#type' => 'textfield',
      '#title' => $this->t('City'),
      '#default_value' => (isset($record['city']) && $_GET['num']) ? $record['city'] : '',
      '#attributes' => ['class' => ['form-control']],
      '#prefix' => '<div class="form-group">',
      '#suffix' => '</div>',
    ];

    $form['state'] = [
      '#type' => 'textfield',
      '#title' => $this->t('State'),
      '#default_value' => (isset($record['state']) && $_GET['num']) ? $record['state'] : '',
      '#attributes' => ['class' => ['form-control']],
      '#prefix' => '<div class="form-group">',
      '#suffix' => '</div>',
    ];

    $form['ecity'] = [
      '#markup' => $this->t('</div>'),
    ];

    $form['eaddinfo'] = [
      '#markup' => $this->t('</div>'),
    ];

    $form['#attached']['library'][] = 'savingscard/savingscard';

    $form['errormark'] = [
      '#markup' => $this->t('<div class="complete__enrollment" id="enrollment">
        <h3 class="Errormsg">To complete your enrollment, you must agree to the terms and submit below.</h3>
        <p>I understand that Otsuka American Pharmaceutical, Inc. (OAPI) or approved parties acting on its behalf may use the information I am providing to send me information and offers that may be of interest to me. OAPI will not sell or transfer my information to any third parties. I understand that from time to time OAI’s privacy policy may change and that I should check OAPI’s website for the most recent version of the <a href="javascript:;" title="Privacy Policy">Privacy Policy</a>. I can request to stop receiving OAPI marketing communications by clicking <a href="/unsubscribe" title="Unsubscribe">Unsubscribe</a>.</p>
        </div><div class="termsofuse">'),
    ];

    $form['agree'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Yes, I agree to the terms of use'),
      '#values' => [0 => 'N', 1 => 'Y'],
      '#required' => FALSE,
      '#prefix' => '<div class="popup__cehckbox" id="frmagree"><div class="round">',
      '#suffix' => '</div></div>',
    ];

    $form['subinfo'] = [
      '#markup' => $this->t('<p>By submitting your information and checking the "YES" box, you agree to the terms of use provided above and in OAPI’s <a href="javascript:;" title="Privacy Policy">Privacy Policy</a>.</p>
        <p> By signing up to register and receiving information, you confirm that you are 18 years old or older and have been prescribed ABILIFY. If you are a caregiver/family member, you are confirming that your loved one is living with a condition for which ABILIFY is indicated.</p>'),
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => 'Sign Up',
      '#attributes' => ['class' => ['btn payretail__btn']],
    ];

    $form['edivsec'] = [
      '#markup' => $this->t('</div></div></div>'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $field = $form_state->getValues();
    $fldFirstname = $field['firstname'];
    $fldLastname = $field['lastname'];
    $fldEmail = $field['email'];
    $fldAddinfo = $field['additional_info'];
    $fldAddress1 = $field['address1'];
    $fldZip = $field['zip'];
    $fldCity = $field['city'];
    $fldState = $field['state'];

    if (preg_match('/[^A-Za-z]/', $fldFirstname)) {
      $form_state->setErrorByName('firstname', $this->t('your first name must in characters without space'));
    }

    if (preg_match('/[^A-Za-z]/', $fldLastname)) {
      $form_state->setErrorByName('lastname', $this->t('your last name must in characters without space'));
    }

    $conn = Database::getConnection();
    $query = $conn->select('savingscard', 's')
      ->condition('email', $fldEmail)
      ->fields('s');
    $record = $query->execute()->fetchAssoc();
    if (!empty($record)) {
      $form_state->setErrorByName('email', $this->t('your email already exists'));
    }

    if ($fldAddinfo == 1) {
      if ($fldAddress1 == '') {
        $form_state->setErrorByName('address1', $this->t('Please fill the Street Address 1'));
      }

      if ($fldZip == '') {
        $form_state->setErrorByName('zip', $this->t('Please fill the Zip'));
      }

      if ($fldCity == '') {
        $form_state->setErrorByName('city', $this->t('Please fill the City'));
      }

      if ($fldState == '') {
        $form_state->setErrorByName('state', $this->t('Please fille the State'));
      }
    }
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $field = $form_state->getValues();
    $fldFirstname = $field['firstname'];
    $fldLastname = $field['lastname'];
    $fldEmail = $field['email'];
    $fldAddinfo = $field['additional_info'];
    $fldAddress1 = $field['address1'];
    $fldAddress2 = $field['address2'];
    $fldZip = $field['zip'];
    $fldCity = $field['city'];
    $fldState = $field['state'];

    if (isset($_GET['num'])) {
      $field = [
        'firstname' => $fldFirstname,
        'lastname' => $fldLastname,
        'email' => $fldEmail,
        'address1' => $fldAddress1,
        'address2' => $fldAddress2,
        'zip' => $fldZip,
        'city' => $fldCity,
        'state' => $fldState,
        'status' => "active",
        'emailstatus' => "subscribe",
      ];
      $query = \Drupal::database();
      $query->update('savingscard')
        ->fields($field)
        ->condition('id', $_GET['num'])
        ->execute();
      drupal_set_message("succesfully updated");
      $form_state->setRedirect($this->t('savingscard.leads_controller_display'));
    }
    else {
      $field = [
        'firstname' => $fldFirstname,
        'lastname' => $fldLastname,
        'email' => $fldEmail,
        'address1' => $fldAddress1,
        'address2' => $fldAddress2,
        'zip' => $fldZip,
        'city' => $fldCity,
        'state' => $fldState,
        'status' => "active",
        'emailstatus' => "subscribe",
      ];

      $query = \Drupal::database();
      $query->insert('savingscard')
        ->fields($field)
        ->execute();
      $mem_num = $_GET['mem_num'];
      $grpid = $_GET['grpid'];
      $ceid = $_GET['CEID'];
      $dest_url = '/savings-card-program/thank-you?&mem_num=' . $mem_num . '&grpid=' . $grpid . '&CEID=' . $ceid;
      $url = Url::fromUri('internal:' . $dest_url);
      $form_state->setRedirectUrl($url);
    }
  }

}
