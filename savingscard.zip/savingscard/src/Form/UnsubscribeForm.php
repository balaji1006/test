<?php

namespace Drupal\savingscard\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

use Drupal\Core\Database\Database;

/**
 * Class SignupForm.
 *
 * @package Drupal\savingscard\Form
 */
class UnsubscribeForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'unsubscribe_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form['sdivmuns'] = [
      '#markup' => $this->t('<div class="row"><div class="col-sm-6">'),
    ];

    $form['fld_unsubscribe'] = [
      '#type' => 'email',
      '#title' => $this->t('Email Address'),
      '#required' => TRUE,
      '#attributes' => ['class' => ['form-control']],
      '#prefix' => '<div class="form-group"><span for="email" class="email-label">Email Address:</span>',
      '#suffix' => '</div>',
    ];

    $form['fld_unsubscribe']['#theme_wrappers'] = [];

    $form['ediveuns'] = [
      '#markup' => $this->t('</div>'),
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => 'Unsubscribe',
      '#attributes' => ['class' => ['btn-submit']],
      '#prefix' => '<div class="col-sm-6">',
      '#suffix' => '</div>',
    ];

    $form['edivmuns'] = [
      '#markup' => $this->t('</div>'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $field = $form_state->getValues();
    $fld_unsubscribe = $field['fld_unsubscribe'];

    $conn = Database::getConnection();
    $query = $conn->select('savingscard', 's')
      ->condition('email', $fld_unsubscribe)
      ->fields('s');
    $record = $query->execute()->fetchAssoc();
    if (empty($record)) {
      $form_state->setErrorByName('email', $this->t('your email not yet subscribe, Please go to subscribe <a href="#">Click Here</a>'));
    }
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $conn = Database::getConnection();

    $field = $form_state->getValues();
    $fld_unsubscribe = $field['fld_unsubscribe'];

    $arrfield = [
      'emailstatus' => 'unsubscribe',
    ];

    $query = $conn->select('savingscard', 's')
      ->condition('email', $fld_unsubscribe)
      ->condition('status', "active")
      ->fields('s');
    $record = $query->execute()->fetchAssoc();

    $query = \Drupal::database();
    $query->update('savingscard')
      ->fields($arrfield)
      ->condition('email', $fld_unsubscribe)
      ->execute();

    $dest_url = '/unsubscribe-confirmation';

    $url = Url::fromUri('internal:' . $dest_url);
    $form_state->setRedirectUrl($url);
  }

}
