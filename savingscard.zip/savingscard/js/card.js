/**
 * @file
 * Javascript behaviors for the Book module.
 */


(function ($) {

  $('.address-info').hide();
  if($('#edit-additional-info').is(':checked'))
  {
    $('.address-info').show();
  }

  $('#signup-form').on("click", "#edit-additional-info", function (e){
    if($('#edit-additional-info').is(':checked'))
    {
      $('.address-info').show();
    } else 
    {
      $('.address-info').hide();
    }
  });

  $('#signup-form').on("submit", function (e){
	  
	if($('#edit-agree').is(':checked'))
	{
		
		
	}		
	
	
    if($('#edit-additional-info').is(':checked'))
    {
      var address = $('#edit-address1');
      if (address.val() == '') {
        address.removeClass("error").addClass("error");
        return false;
      } 
      
      var zipcode = $('#edit-zip');
      if (zipcode.val() == '') {
        zipcode.removeClass("error").addClass("error");
        return false;
      } 
      
      var city = $('#edit-city');
      if (city.val() == '') {
        city.removeClass("error").addClass("error");
        return false;
      } 
      
      var state = $('#edit-state');
      if (state.val() == '') {
        state.removeClass("error").addClass("error");
        return false;
      } 
    }
    return true;
  });

})(jQuery);

